import express from 'express';
import { protect, requireRole } from '../middleware/auth.js';
import upload from '../middleware/uploadMiddleware.js';
import {
  getMyProfile,
  updateMyProfile,
  getProfile,
  updateProfileAsHR,
  uploadMyPhoto,
  uploadProfilePhotoAsHR,
} from '../controller/profileController.js';

const router = express.Router();

router.get('/me', protect, getMyProfile);
router.put('/me', protect, updateMyProfile);
router.post('/me/photo', protect, upload.single('photo'), uploadMyPhoto);

router.get('/:userId', protect, requireRole('manager', 'hr'), getProfile);
router.put('/:userId', protect, requireRole('hr'), updateProfileAsHR);
router.post('/:userId/photo', protect, requireRole('hr'), upload.single('photo'), uploadProfilePhotoAsHR);

export default router;