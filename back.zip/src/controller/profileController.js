import EmployeeProfile from '../models/people/employeeProfile.js';
import { scopeFilter } from '../utils/scope.js';
import { deletePhotoFile } from '../middleware/uploadMiddleware.js';

export const getMyProfile = async (req, res) => {
  const profile = await EmployeeProfile.findOne({ userId: req.user._id });
  if (!profile) return res.status(404).json({ message: 'Profile not found' });
  res.json({ profile });
};


export const getProfile = async (req, res) => {
  const allowed = await scopeFilter(req.user, 'userId');

  const profile = await EmployeeProfile.findOne({
    $and: [{ userId: req.params.userId }, allowed],
  });

  if (!profile) return res.status(404).json({ message: 'Profile not found' });
  res.json({ profile });
};


export const updateMyProfile = async (req, res) => {
  const { phoneNumber, address, emergencyContact } = req.body;

  const profile = await EmployeeProfile.findOneAndUpdate(
    { userId: req.user._id },
    {
      $set: {
        'personalInfo.phoneNumber': phoneNumber,
        address,
        emergencyContact,
      },
    },
    { new: true, runValidators: true }
  );

  if (!profile) return res.status(404).json({ message: 'Profile not found' });
  res.json({ profile });
};

export const updateProfileAsHR = async (req, res) => {
  const { personalInfo, address, dateOfBirth, hireDate, jobTitle, employmentType, emergencyContact, sensitive } = req.body;

  const profile = await EmployeeProfile.findOneAndUpdate(
    { userId: req.params.userId },
    { personalInfo, address, dateOfBirth, hireDate, jobTitle, employmentType, emergencyContact, sensitive },
    { new: true, runValidators: true }
  );

  if (!profile) return res.status(404).json({ message: 'Profile not found' });
  res.json({ profile });
};



export const uploadMyPhoto = async (req, res) => {
  if (!req.file) return res.status(400).json({ message: 'No photo file was provided.' });

  const existing = await EmployeeProfile.findOne({ userId: req.user._id });
  if (!existing) return res.status(404).json({ message: 'Profile not found' });

  const photoUrl = `/uploads/profile-photos/${req.file.filename}`;

  const profile = await EmployeeProfile.findOneAndUpdate(
    { userId: req.user._id },
    { $set: { profilePhoto: photoUrl } },
    { new: true }
  );

  deletePhotoFile(existing.profilePhoto); 
  res.json({ profile });
};

export const uploadProfilePhotoAsHR = async (req, res) => {
  if (!req.file) return res.status(400).json({ message: 'No photo file was provided.' });

  const existing = await EmployeeProfile.findOne({ userId: req.params.userId });
  if (!existing) return res.status(404).json({ message: 'Profile not found' });

  const photoUrl = `/uploads/profile-photos/${req.file.filename}`;

  const profile = await EmployeeProfile.findOneAndUpdate(
    { userId: req.params.userId },
    { $set: { profilePhoto: photoUrl } },
    { new: true }
  );

  deletePhotoFile(existing.profilePhoto);
  res.json({ profile });
};