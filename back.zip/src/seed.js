// seed.js: creates demo users so you can log in. For development only.
// Run it ONCE, from the backend folder:  node src/seed.js
import dns from "node:dns";
import 'dotenv/config';
import mongoose from 'mongoose';
import User from './models/people/User.js';

dns.setServers(["8.8.8.8", "8.8.4.4"]);


const password = 'Password123!'; // every demo user gets this password

await mongoose.connect(process.env.MONGO_URI);

// The User model hashes the password for us when it saves
await User.create({ email: 'hr@example.com', password, role: 'hr', status: 'active' });

const manager = await User.create({ email: 'manager@example.com', password, role: 'manager', status: 'active' });

// Two employees who report to the manager (so you can test a shift swap between them)
await User.create({ email: 'ada@example.com', password, role: 'employee', managerId: manager._id, status: 'active' });
await User.create({ email: 'tunde@example.com', password, role: 'employee', managerId: manager._id, status: 'active' });

console.log('Demo users created. The password for all of them is: Password123!');
await mongoose.disconnect();
