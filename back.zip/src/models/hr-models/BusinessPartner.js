import mongoose from 'mongoose';
import personalInfoSchema from '../nestedSchema/personalInfo.js';

const businessPartnerSchema = new mongoose.Schema(
    {
    personalInfo:
     {
         type: personalInfoSchema,
         default: () => ({}),
    },
    companyName: {
     type: String,
    required: true,
    },
    contractDates: {
        startDate: {
            type: Date,
            required: true,
        },
        endDate: {
            type: Date,
            required: true,
        }
    },
    notes: {
        type: String
    },
    createdBy: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        default: null,
        index: true,
    }

    }
);

const BusinessPartner = mongoose.model('BusinessPartner','businessPartnerSchema')

export default BusinessPartner;